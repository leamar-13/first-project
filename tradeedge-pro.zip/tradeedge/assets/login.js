// login.js
function switchTab(tab) {
  document.getElementById('loginForm').style.display  = tab === 'login'  ? 'block' : 'none';
  document.getElementById('signupForm').style.display = tab === 'signup' ? 'block' : 'none';
  document.getElementById('loginTab').classList.toggle('active',  tab === 'login');
  document.getElementById('signupTab').classList.toggle('active', tab === 'signup');
}

function togglePw(id, btn) {
  const inp = document.getElementById(id);
  if (!inp) return;
  inp.type = inp.type === 'password' ? 'text' : 'password';
  btn.textContent = inp.type === 'password' ? '👁' : '🙈';
}

function checkStrength(val) {
  let score = 0;
  if (val.length >= 8)  score++;
  if (/[A-Z]/.test(val)) score++;
  if (/[0-9]/.test(val)) score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;

  const bars = [1,2,3,4].map(i => document.getElementById(`psb${i}`));
  const colors = ['#ef4444','#f97316','#eab308','#22c55e'];
  const labels = ['Weak','Fair','Good','Strong'];
  bars.forEach((b, i) => { if (b) b.style.background = i < score ? colors[score-1] : 'var(--border)'; });
  const lbl = document.getElementById('pwsLabel');
  if (lbl) lbl.textContent = score ? labels[score-1] : '—';
}

function handleAuth(mode) {
  showToast(mode === 'login'
    ? '✓ Logged in! (Demo — backend not connected)'
    : '✓ Account created! Check your email. (Demo)');
}

function handleSocial(provider) {
  showToast(`${provider} sign-in coming soon!`);
}

function showToast(msg) {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();
  const t = document.createElement('div');
  t.className = 'toast'; t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}
